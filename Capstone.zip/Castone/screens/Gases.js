import React from 'react';
import {  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  Alert,
  View, } from 'react-native';
  

export default class Gases extends React.Component {
  static navigationOptions = {
    header: null,

  };

  constructor(){
    super();
    this.state = {
      codata: '',
      nh3data: '',
      ch4data: '',
      h2sdata: '',
    }
  }

  getData(){
    fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=co')
    .then((response) => response.json())
      .then((responseJson) => {
         this.setState({
            codata: responseJson
         })
  }).catch((error) => {
    console.error(error);
 });

  fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=nh3')
  .then((response) => response.json())
    .then((responseJson) => {
       this.setState({
          nh3data: responseJson
       })
}).catch((error) => {
  console.error(error);
});

fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=ch4')
  .then((response) => response.json())
    .then((responseJson) => {
       this.setState({
          ch4data: responseJson
       })
}).catch((error) => {
  console.error(error);
});

fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=h2s')
  .then((response) => response.json())
    .then((responseJson) => {
       this.setState({
          h2sdata: responseJson
       })
}).catch((error) => {
  console.error(error);
});
  
}

  componentDidMount(){
    this.interval = setInterval(() => this.getData(), 5000);
    this.interval1 = setInterval(() => this.nh3_checker(), 20000);
    this.interval2 = setInterval(() => this.h2s_checker(), 20000);
  }

  componentWillUnmount() {
    clearInterval(this.interval);
    clearInterval(this.interval1);
    clearInterval(this.interval2);
  } 

  nh3_checker=()=>{
    var nh3d = parseInt(this.state.nh3data);
    if( nh3d > 50){
        Alert.alert("NH3 Level Exceeded Threshhold!");
    }
  }

  h2s_checker=()=>{
    var h2sd = parseInt(this.state.h2sdata);
    if( h2sd > 90){
        Alert.alert("H2S Level Exceeded Threshhold!");
    }
  }

  

  render() {
    return (
      <View style={styles.container}>

        <Image style={styles.img} source={require('../assets/images/gases.jpg')}/>

        <ScrollView style={styles.container}>

        <View style={{flex: 1, flexDirection: 'row', paddingTop:35}}>

        <Text style={styles.text}>CO:</Text>
        <Text style={styles.textd}>{this.state.codata} ppm</Text>

        </View>

        <View style={{flex: 1, flexDirection: 'row'}}>

        <Text style={styles.text}>NH3:</Text>
        <Text style={styles.textd}>{this.state.nh3data} ppm</Text>

        </View>

        <View style={{flex: 1, flexDirection: 'row'}}>

        <Text style={styles.text}>CH4:</Text>
        <Text style={styles.textd}>{this.state.ch4data} ppm</Text>

        </View>

        <View style={{flex: 1, flexDirection: 'row'}}>

        <Text style={styles.text}>H2S:</Text>
        <Text style={styles.textd}>{this.state.h2sdata} ppm</Text>

        </View>

        </ScrollView>
        </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 10,

  },
  t:{
    alignContent: 'center',
    alignItems: 'center',
  },
  text:{
    fontSize:35,
  },
  textd:{
    fontSize: 35,
    color:'grey',
    paddingBottom: 50,
    paddingLeft: 35
  },
  img:{
    paddingTop:0,
    flex:1, 
    height: undefined, 
    width: undefined
  }
});
