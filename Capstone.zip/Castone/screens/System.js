import React from 'react';
import {
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

export default class System extends React.Component {
  static navigationOptions = {
    header: null,
  };

  constructor(){
    super();
    this.state = {
      getth: '',
      getgas: '',
      getlight: '',
      getmotion: '',
    }
  }

  getData(){
    fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=th')
    .then((response) => response.json())
      .then((responseJson) => {
         this.setState({
            getth: responseJson
         })
  }).catch((error) => {
    console.error(error);
 });

  fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=gas')
  .then((response) => response.json())
    .then((responseJson) => {
       this.setState({
          getgas: responseJson
       })
  }).catch((error) => {
    console.error(error);
 });

  fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=lights')
  .then((response) => response.json())
    .then((responseJson) => {
       this.setState({
          getlight: responseJson
       })
  }).catch((error) => {
    console.error(error);
 });

  fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=motion')
  .then((response) => response.json())
    .then((responseJson) => {
       this.setState({
          getmotion: responseJson
       })
  }).catch((error) => {
    console.error(error);
 });

  }

  componentDidMount(){
    this.interval = setInterval(() => this.getData(), 5000);
  }

  componentWillUnmount() {
    clearInterval(this.interval);
  }

  render() {
    return (
      <View style={styles.container}>
        <ScrollView style={styles.container}>

        <View style={{flex: 1, flexDirection: 'row', paddingTop:35}}>
        <Text style={styles.text}>Temp:</Text>
        <Text style={styles.textd}>{this.state.getth}</Text>
        </View>

        <View style={{flex: 1, flexDirection: 'row'}}>
        <Text style={styles.text}>Gases:</Text>
        <Text style={styles.textd}>{this.state.getgas}</Text>
        </View>

        <View style={{flex: 1, flexDirection: 'row'}}>
        <Text style={styles.text}>Light:</Text>
        <Text style={styles.textd}>{this.state.getlight}</Text>
        </View>

        <View style={{flex: 1, flexDirection: 'row'}}>
        <Text style={styles.text}>Motion:</Text>
        <Text style={styles.textd}>{this.state.getmotion}</Text>
        </View>

        </ScrollView>
      </View>
    );
  }
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 10,

  },
  t:{
    alignContent: 'center',
    alignItems: 'center',
  },
  text:{
    fontSize:35,
  },
  textd:{
    fontSize: 35,
    color:'grey',
    paddingBottom: 50,
    paddingLeft: 25
  },
  img:{
    paddingTop:0,
    flex:1, 
    height: undefined, 
    width: undefined
  }
});
