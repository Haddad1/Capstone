import React from 'react';
import {  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  Alert,
  View, } from 'react-native';


export default class Light_Motion extends React.Component {
  static navigationOptions = {
    header: null
  };

  constructor(){
    super();
    this.state = {
      m1data: '',
      m2data: '',
      lightdata: '',
      m1state: 'no',
      m2state: 'no',
    }
  }

  getData(){
    fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=m1')
    .then((response) => response.json())
      .then((responseJson) => {
         //console.log(responseJson);
         this.setState({
            m1data: responseJson
         })
  }).catch((error) => {
    console.error(error);
 });

  fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=m2')
  .then((response) => response.json())
    .then((responseJson) => {
       //console.log(responseJson);
       this.setState({
          m2data: responseJson
       })
}).catch((error) => {
  console.error(error);
});

  fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=light')
    .then((response) => response.json())
      .then((responseJson) => {
        //console.log(responseJson);
        this.setState({
            lightdata: responseJson
       })
}).catch((error) => {
  console.error(error);
});
}
  componentDidMount(){
    this.interval = setInterval(() => this.getData(), 5000);
    this.interval1 = setInterval(() => this.motion1_checker(), 20000);
    this.interval2 = setInterval(() => this.motion2_checker(), 20000);
  }

  componentWillUnmount() {
    clearInterval(this.interval);
    clearInterval(this.interval1);
    clearInterval(this.interval2);
  }

  motion1_checker=()=>{
 
    if( this.state.m1data == "on"){
      if(this.state.m1state == "no"){
        Alert.alert("Motion Detected!");
        this.state.m1state == "yes";
    }else{
      this.state.m1state == "no";
    }
    }
  }

  motion2_checker=()=>{
 
    if( this.state.m2data == "on"){
      if(this.state.m2state == "no"){
        Alert.alert("Motion Detected!");
        this.state.m2state == "yes";
    }else{
      this.state.m2state == "no";
    }
    }
  }

  render() {
    return (
      <View style={styles.container}>
        <Image style={styles.img} source={require('../assets/images/motion.png')}/>

        <ScrollView style={styles.container}>

        <View style={{flex: 1, flexDirection: 'row', paddingTop:35}}>
        
        <Text style={styles.text}>Motion 1:</Text>

        <Text style={styles.textd}>{this.state.m1data}</Text>
        </View>

        <View style={{flex: 1, flexDirection: 'row', paddingTop:35}}>
        
        <Text style={styles.text}>Motion 2:</Text>

        <Text style={styles.textd}>{this.state.m2data}</Text>
        </View>

        <View style={{flex: 1, flexDirection: 'row'}}>
        <Text style={styles.text}>Light:</Text>

        <Text style={styles.textd}>{this.state.lightdata}</Text>
        </View>
        </ScrollView>

      </View>
    );

  }
}




const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 10,

  },
  t:{
    alignContent: 'center',
    alignItems: 'center',
  },
  text:{
    fontSize:35,
  },
  textd:{
    fontSize: 35,
    color:'grey',
    paddingBottom: 50,
    paddingLeft: 35
  },
  img:{
    paddingTop:0,
    flex:1, 
    height: undefined, 
    width: undefined
  }
});
