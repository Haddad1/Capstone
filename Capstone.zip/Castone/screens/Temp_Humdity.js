import React from 'react';
import {
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

export default class Temp_Humdity extends React.Component {
  static navigationOptions = {
    header: null,
    title: 'Temp & Humidity'
  };

  constructor(){
    super();
    this.state = {
      tempdata: '',
      humdata: '',
    }
  }

  getData(){
    fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=temp')
    .then((response) => response.json())
      .then((responseJson) => {
         this.setState({
            tempdata: responseJson
         })
  }).catch((error) => {
    console.error(error);
 });

  fetch('https://script.google.com/macros/s/AKfycbz9MDgVVE0jH0zMQB5aAMjjeCYnvYmd90OKUft3tgNJAz5XNxFq/exec?arg=hum')
  .then((response) => response.json())
    .then((responseJson) => {
       this.setState({
          humdata: responseJson
       })
  }).catch((error) => {
    console.error(error);
 });
  }

  componentDidMount(){
    this.interval = setInterval(() => this.getData(), 5000);
  }

  componentWillUnmount() {
    clearInterval(this.interval);
  }

  render() {

    return (
      <View style={styles.container}>
        <Image style={styles.img} source={require('../assets/images/tah.jpg')}/>

        <ScrollView style={styles.container}>

        <View style={{flex: 1, flexDirection: 'row', paddingTop:35}}>
        <Text style={styles.text}>Temperature:</Text>

        <Text style={styles.textd}>{this.state.tempdata} C</Text>
        </View>
        <View style={{flex: 1, flexDirection: 'row'}}>
        <Text style={styles.text}>Humidity:</Text>

        <Text style={styles.textd}>{this.state.humdata} %</Text>
        </View>
        </ScrollView>

      </View>
    );
  }
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 10,

  },
  t:{
    alignContent: 'center',
    alignItems: 'center',
  },
  text:{
    fontSize:35,
  },
  textd:{
    fontSize: 35,
    color:'grey',
    paddingBottom: 50,
    paddingLeft: 35
  },
  img:{
    paddingTop:0,
    flex:1, 
    height: undefined, 
    width: undefined
  }
});
