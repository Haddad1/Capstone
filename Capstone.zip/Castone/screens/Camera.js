import React, { Component } from 'react';
import { StyleSheet, Text, View, Dimensions, Button, Image } from 'react-native';
import { Constants, Video, ImagePicker } from 'expo';
import { MaterialIcons } from '@expo/vector-icons';



export default class Camera extends Component {
    state = {
    mute: false,
    shouldPlay: true,
    image: null,
  }

  
  handlePlayAndPause = () => {  
    this.setState((prevState) => ({
       shouldPlay: !prevState.shouldPlay  
    }));
  }
  
  handleVolume = () => {
    this.setState(prevState => ({
      mute: !prevState.mute,  
    }));
  }
  render() {
  const { width } = Dimensions.get('window');
  let { image } = this.state;
		
  return (
    <View style={styles.container}>
      <View>
          <Button
          title="Pick an image from camera roll"
          onPress={this._pickImage}
          />
          </View>
          <Video
            source={{ uri: 'nodejs-assets\nodejs-project\r.mp4' }}
            shouldPlay={this.state.shouldPlay}
            isLooping
            resizeMode="cover"
            style={{ width, height: 500 }}
            isMuted={this.state.mute}
            
          />
          <View style={styles.controlBar}>
            <MaterialIcons 
              name={this.state.mute ? "volume-mute" : "volume-up"}
              size={45} 
              color="white" 
              onPress={this.handleVolume} 
            />
            <MaterialIcons 
              name={this.state.shouldPlay ? "pause" : "play-arrow"} 
              size={45} 
              color="white" 
              onPress={this.handlePlayAndPause} 
            />
          </View>
        </View>
  );
}

_pickImage = async () => {
  let result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: 'All',
    allowsEditing: true,
    aspect: [4, 3],
  });

  console.log(result);

  if (!result.cancelled) {
    this.setState({ image: result.uri });
  }
};
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
  },
  controlBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 45,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  }
});
