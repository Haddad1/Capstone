import React from 'react';
import { Platform } from 'react-native';
import { createStackNavigator, createBottomTabNavigator } from 'react-navigation';

import TabBarIcon from '../components/TabBarIcon';
import Temp_Humdity from '../screens/Temp_Humdity';
import Gases from '../screens/Gases';
import Light_Motion from '../screens/Light_Motion';
import System from '../screens/System';
import Camera from '../screens/Camera';

const Temp_ = createStackNavigator({
  Temp_Humdity: Temp_Humdity,
});

Temp_.navigationOptions = {
  tabBarLabel: 'Temp & Humidity',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name={
        Platform.OS === 'ios'
          ? `ios-thermometer${focused ? '' : '-outline'}`
          : 'md-thermometer'
      }
    />
  ),
};

const Gase = createStackNavigator({
  Gases: Gases,
});

Gase.navigationOptions = {
  tabBarLabel: 'Gases',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name= 'ios-nuclear'
      />
  ),
};

const  Light_ = createStackNavigator({
  Light_Motion: Light_Motion,
});

Light_.navigationOptions = {
  tabBarLabel: 'Light & Motion',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name='ios-walk'
    />
  ),
};

const Cam = createStackNavigator({
  Camera: Camera,
});

Cam.navigationOptions = {
  tabBarLabel: 'Camera',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name= 'ios-camera'
      />
  ),
};


const Systems = createStackNavigator({
  System: System,
});

Systems.navigationOptions = {
  tabBarLabel: 'Systems',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name= 'ios-settings'
      />
  ),
};

export default createBottomTabNavigator({
  Temp_,
  Gase,
  Light_,
  Cam,
  Systems,
});
